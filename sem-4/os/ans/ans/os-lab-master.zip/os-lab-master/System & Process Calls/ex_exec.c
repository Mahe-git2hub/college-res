#include<stdio.h>
int main()
{
	printf("File ex_exec executed\n");
    printf("Hello World\n");    
    return 0;
}